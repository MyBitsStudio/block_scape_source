package com.alex.store;

public class FileReference {

	private int nameHash;

	public int getNameHash() {
		return nameHash;
	}

	public void setNameHash(int nameHash) {
		this.nameHash = nameHash;
	}
	
}
