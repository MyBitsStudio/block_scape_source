package com.alex.util.bzip2;
/* BZip2BlockEntry - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class BZip2BlockEntry {
	int[][] anIntArrayArray4894;
	int anInt4895 = 16;
	boolean[] aBoolArray4896;
	int anInt4897 = 6;
	int anInt4898 = 50;
	int anInt4899 = 18002;
	int[] anIntArray4900;
	int anInt4901;
	int anInt4902;
	int anInt4903;
	byte aByte4904;
	byte[] aByteArray4905;
	int anInt4906;
	int anInt4907;
	int anInt4908;
	byte[] aByteArray4909;
	int anInt4910;
	int anInt4911;
	int anInt4912;
	int anInt4913;
	int anInt4914;
	int anInt4915;
	int[] anIntArray4916;
	byte[] aByteArray4917;
	int[][] anIntArrayArray4918;
	int anInt4919;
	int anInt4920 = 4096;
	boolean[] aBoolArray4921;
	public static int[] anIntArray4922;
	byte[] aByteArray4923;
	int anInt4924;
	byte[] aByteArray4925;
	byte[] aByteArray4926;
	byte[][] getLength;
	int[] anIntArray4927;
	int[][] anIntArrayArray4928;
	int anInt4929 = 258;
	int[] anIntArray4930;
	int anInt4931;
	BZip2BlockEntry() {
		this.anInt4901 = 0;
		this.anInt4913 = 0;
		this.anIntArray4900 = new int[256];
		this.anIntArray4927 = new int[257];
		this.aBoolArray4896 = new boolean[256];
		this.aBoolArray4921 = new boolean[16];
		this.aByteArray4905 = new byte[256];
		this.aByteArray4923 = new byte[4096];
		this.anIntArray4916 = new int[16];
		this.aByteArray4925 = new byte[18002];
		this.aByteArray4926 = new byte[18002];
		this.getLength = new byte[6][258];
		this.anIntArrayArray4894 = new int[6][258];
		this.anIntArrayArray4928 = new int[6][258];
		this.anIntArrayArray4918 = new int[6][258];
		this.anIntArray4930 = new int[6];
	}

}
