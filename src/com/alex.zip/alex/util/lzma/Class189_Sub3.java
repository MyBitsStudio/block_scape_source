package com.alex.util.lzma;

/**
 * Created at: Jul 30, 2016 8:54:48 AM
 * @author Walied-Yassen A.K.A Cody
 */
public class Class189_Sub3 {
	public static int method8994(int i, int i_10_) {
		i -= 2;
		if (i < 4) {
			return i;
		}
		return 3;
	}
}
