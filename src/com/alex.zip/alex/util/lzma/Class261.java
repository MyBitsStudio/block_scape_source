package com.alex.util.lzma;

/**
 * Created at: Jul 30, 2016 8:55:14 AM
 * @author Walied-Yassen A.K.A Cody
 */
public class Class261 {
    public static int method3603(int i, byte i_36_) {
	return i < 7 ? 8 : 11;
    }
    
}
