package com.alex.util.lzma;

/**
 * Created at: Jul 30, 2016 8:55:42 AM
 * @author Walied-Yassen A.K.A Cody
 */
public class Class290 {
    
    public static int method3853(int i, byte i_17_) {
	return i < 7 ? 9 : 11;
    }
    
}
