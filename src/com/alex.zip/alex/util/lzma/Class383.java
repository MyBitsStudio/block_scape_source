package com.alex.util.lzma;

/**
 * Created at: Jul 30, 2016 8:55:56 AM
 * @author Walied-Yassen A.K.A Cody
 */
public class Class383 {
	  public static int method4775(int i, byte i_7_) {
			if (i < 4) {
				return 0;
			}
			if (i < 10) {
				return i - 3;
			}
			return i - 6;
		    }
}
