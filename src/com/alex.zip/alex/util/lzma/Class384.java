package com.alex.util.lzma;

/**
 * Created at: Jul 30, 2016 8:56:20 AM
 * @author Walied-Yassen A.K.A Cody
 */
public class Class384 {
    
    public static int method4785(byte i) {
	return 0;
    }
    
}
