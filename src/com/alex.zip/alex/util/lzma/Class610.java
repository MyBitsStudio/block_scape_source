package com.alex.util.lzma;

/**
 * Created at: Jul 30, 2016 8:56:06 AM
 * @author Walied-Yassen A.K.A Cody
 */
public class Class610 {
    public static boolean method7280(int i, int i_7_) {
	return i < 7;
    }
    
}
