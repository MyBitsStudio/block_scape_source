package com.alex.util.lzma;

/**
 * Created at: Jul 30, 2016 8:54:35 AM
 * @author Walied-Yassen A.K.A Cody
 */
public class Class695_Sub26 {
    public static int method10113(int i, byte i_3_) {
	return i < 7 ? 7 : 10;
    }
}
