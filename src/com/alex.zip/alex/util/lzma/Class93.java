package com.alex.util.lzma;

import java.util.Arrays;

/**
 * Created at: Jul 30, 2016 8:52:47 AM
 * @author Walied-Yassen A.K.A Cody
 */
public class Class93 {
	public static void method1305(short[] is, byte i) {
		Arrays.fill(is, (short) 1024);
	}

}
